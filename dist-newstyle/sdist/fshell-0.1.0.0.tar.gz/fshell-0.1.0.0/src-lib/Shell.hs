module Shell (initShell) where

import System.Exit ()
import System.Directory (setCurrentDirectory, getCurrentDirectory)
import System.Process
import System.IO


-- Shell initialize.
initShell :: [String] -> IO ()
initShell str = do
  let (command:arguments) = str
  (Just hin, Just hout, Just herr, _) <- createProcess (proc command arguments)
    { std_in = CreatePipe, std_out = CreatePipe, std_err = CreatePipe }
  output <- hGetContents hout
  putStrLn output


-- TODO : Create a configuration file.
-- TODO : Colorize output.
-- TODO : Optimize shell.
-- TODO : Create theming config.
-- TODO : Code is fully haskell. (Re-write from rust.)

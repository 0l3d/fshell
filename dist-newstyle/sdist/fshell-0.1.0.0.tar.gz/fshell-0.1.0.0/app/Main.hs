module Main where

import qualified Shell (initShell)
import System.IO

main :: IO ()
main = do
  putStr "-> "
  hFlush stdout
  command <- getLine
  let commandList = words command
  Shell.initShell commandList
